
public class ISBNMismatchException extends Exception {

	
	public ISBNMismatchException(String message) {
		super(message);
	}
}
