
public interface LibraryData {

	

public double calculate_cost();

	 
	 
}