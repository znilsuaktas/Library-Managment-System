
public class NotValidDateException extends Exception {

public NotValidDateException(String message) {
	super(message);
}

}
