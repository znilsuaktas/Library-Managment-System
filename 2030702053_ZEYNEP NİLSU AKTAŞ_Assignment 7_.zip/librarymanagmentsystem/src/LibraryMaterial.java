
public abstract class LibraryMaterial {

	
 protected double cost;  

 
 public double getCost() {
	 
	 return cost;
 }
 
 
 public void setCost(double cost) {
	 
	 this.cost=cost;
 }
 
 
}